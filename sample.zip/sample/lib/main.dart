import 'package:sample/pages/aboutme.dart';
import 'package:sample/pages/home.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      home: HomePage(),
      routes: {
        '/about': (context) => aboutme()
      },
      title: 'Sanjay Krish- Personal Portfolio'
    );
  }
}
