import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Portfolio",style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize:20,
        color: Colors.blue
    ),),
      ),
        body: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment:  CrossAxisAlignment.center,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment:  CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min  ,
              children: [
                Text(
                  "Hi I am Sanjay Krish",
            style: TextStyle(
            fontSize: 50,
            fontWeight: FontWeight.bold
        ),
                ),
    Text(
    "I am from SRM",
    style: TextStyle(
    fontSize: 25,
    color: Colors.red
    ),
    ),
    TextButton(
    onPressed: (){
      print("Hello world");
      Navigator.pushNamed(context, '/about');
    },
    child: Text("about me"),
    style: ButtonStyle(
    backgroundColor: MaterialStateProperty.all(Colors.amber)

    )
    )
              ],
            ),
            const SizedBox(width:40,),
            const SizedBox(width:40,),
            Hero(
              tag:'Photo',
              child: Container(
                height: 300,
                width: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    image: AssetImage("assets/1703064254251.jpg")
                  ),
                  boxShadow:[
                    BoxShadow(
                  color: Colors.red,
                  offset: Offset(0,0),
                  blurRadius: 7,
                  spreadRadius: 9,
                ),
                ],
              ),
                  ),
            ),
    ],



    ),

    ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Container(
          height: 50,
          width: 300,
          decoration: BoxDecoration(
            color: Colors.amber,
            borderRadius: BorderRadius.circular(50),
            boxShadow:[
              BoxShadow(
                color: Colors.red,
                offset: Offset(0,0),
                blurRadius: 5,
                spreadRadius: 7,
              ),
            ],
          ),

          child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                InkWell(
                  onTap: () async {
                    await launchUrl(Uri.parse("https://github.com/SanjayKrish664"));
      },


                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.asset('assets/github.png'),) ,
                ),
                 Padding(
                   padding: const EdgeInsets.all(8.0),
                   child: Image.asset('assets/email.png'),),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.asset('assets/instagram.png'),),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Image.asset('assets/linkedin.png'),)]
                    )
      )

                  );


  }


}



