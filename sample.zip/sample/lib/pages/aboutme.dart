import 'package:flutter/material.dart';

class aboutme extends StatelessWidget {
  const aboutme ({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [Container(
            height: 300,
            width: 300,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              image: DecorationImage(
                  image: AssetImage("assets/1703064254251.jpg")
              ),
              boxShadow:[
                BoxShadow(
                  color: Colors.red,
                  offset: Offset(0,0),
                  blurRadius: 7,
                  spreadRadius: 9,
                ),
              ],
            ),
          ),
            const SizedBox(width: 40,),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Developer\n Data Science",
                      style: TextStyle(
                       fontSize: 30,
                       fontWeight: FontWeight.bold,
                       color: Colors.black
                      )
                ),
                const SizedBox(height: 20,),
                Text("""
                 Hi this is sanjay
                 from BCA DS
                 """,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: 20,
                      color: Colors.grey


                ),)
              ]

            )
          ],
        )
      ),
    );
  }
}
